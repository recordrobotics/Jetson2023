
#pragma once

#include <ntcore.h>

namespace pyntcore {

void attachLogging(NT_Inst instance);
void detachLogging(NT_Inst instance);

}; // namespace pyntcore
