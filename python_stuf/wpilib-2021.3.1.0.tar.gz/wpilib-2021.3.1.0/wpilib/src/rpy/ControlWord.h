#include <tuple>

namespace rpy {

std::tuple<bool, bool, bool> GetControlState();

} // namespace rpy
