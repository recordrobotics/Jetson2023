import wpilib.controller


def test_wpilib_controller():
    pass
