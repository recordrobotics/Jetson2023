# tests the internals
import halsim_gui._init_halsim_gui


def test_halsim_gui():
    pass
