
.. _wpimath_api:

WPIMath API
-----------

.. toctree::

  wpimath
  wpimath.controller
  wpimath.estimator
  wpimath.geometry
  wpimath.kinematics
  wpimath.spline
  wpimath.system
  wpimath.system.plant
  wpimath.trajectory
  wpimath.trajectory.constraint
