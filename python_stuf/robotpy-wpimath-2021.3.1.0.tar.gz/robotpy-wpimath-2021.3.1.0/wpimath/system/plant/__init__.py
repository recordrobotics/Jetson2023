from ..._controls._controls.plant import DCMotor

__all__ = ["DCMotor"]
