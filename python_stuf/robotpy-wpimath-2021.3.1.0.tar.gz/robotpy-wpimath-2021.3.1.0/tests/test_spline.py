import wpimath.spline


def test_todo():
    pass
