import hal.simulation


def test_hal_simulation():
    pass
