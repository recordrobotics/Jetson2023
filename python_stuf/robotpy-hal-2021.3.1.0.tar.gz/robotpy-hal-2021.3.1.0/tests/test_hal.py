import hal


def test_hal():
    pass
